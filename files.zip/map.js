/* =====================================================
   MAP — 2D tile map renderer (Leaflet + OSM tiles)
   Loaded on demand when user switches to Map view.
   Shares the same data layer model as globe.js
   ===================================================== */

const Map2D = (() => {

  let leafletMap  = null;
  let leafletReady = false;

  // Leaflet layer groups
  const layerGroups = {
    flights:   null,
    ships:     null,
    satellites: null,
    jamming:   null,
    noflyzone: null,
  };

  const COLORS = {
    flights:   '#00ffe0',
    ships:     '#4488ff',
    satellites:'#ffd700',
    jamming:   '#ff4444',
    noflyzone: '#ff8800',
  };

  // ---- Lazy-load Leaflet CSS + JS ----
  function _loadLeaflet() {
    return new Promise((resolve) => {
      if (window.L) { resolve(); return; }

      const css = document.createElement('link');
      css.rel  = 'stylesheet';
      css.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
      document.head.appendChild(css);

      const script = document.createElement('script');
      script.src   = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
      script.onload = resolve;
      document.head.appendChild(script);
    });
  }

  // ---- Override Leaflet tile styling for dark theme ----
  const TILE_STYLE = `
    .leaflet-tile-pane { filter: invert(1) hue-rotate(180deg) brightness(0.75) contrast(1.1) saturate(0.6); }
    .leaflet-container { background: #020408; font-family: 'Space Mono', monospace; }
    .leaflet-popup-content-wrapper {
      background: rgba(2,10,20,0.92);
      border: 1px solid rgba(0,255,224,0.2);
      color: #c8d8e8;
      border-radius: 0;
      font-family: 'Space Mono', monospace;
      font-size: 11px;
    }
    .leaflet-popup-tip { background: rgba(2,10,20,0.92); }
  `;

  async function init(container) {
    if (leafletReady) return;
    await _loadLeaflet();

    // Inject dark-mode tile CSS
    const style = document.createElement('style');
    style.textContent = TILE_STYLE;
    document.head.appendChild(style);

    leafletMap = L.map(container, {
      center: [20, 10],
      zoom: 3,
      zoomControl: false,
      attributionControl: false,
    });

    // OpenStreetMap tiles (free, no API key)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      attribution: '© OpenStreetMap contributors',
    }).addTo(leafletMap);

    // Attribution (small, bottom right)
    L.control.attribution({ position: 'bottomright', prefix: false }).addTo(leafletMap);

    // Create layer groups
    Object.keys(layerGroups).forEach(key => {
      layerGroups[key] = L.layerGroup().addTo(leafletMap);
    });

    leafletReady = true;
  }

  // ---- Populate all layers ----
  function populate(flights, ships, satellites, jammingZones, noFlyZones) {
    if (!leafletReady) return;
    _populateFlights(flights);
    _populateShips(ships);
    _populateSatellites(satellites);
    _populateJamming(jammingZones);
    _populateNoFly(noFlyZones);
  }

  function _dotIcon(color, size = 8) {
    return L.divIcon({
      className: '',
      html: `<div style="
        width:${size}px; height:${size}px;
        background:${color};
        border-radius:50%;
        box-shadow: 0 0 6px ${color};
        border: 1px solid rgba(255,255,255,0.3);
      "></div>`,
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2],
    });
  }

  function _populateFlights(flights) {
    layerGroups.flights.clearLayers();
    flights.forEach(f => {
      const marker = L.marker([f.lat, f.lon], { icon: _dotIcon(COLORS.flights, 7) });
      marker.bindPopup(`
        <b style="color:#00ffe0">${f.callsign}</b><br>
        Speed: ${Math.round(f.speed)} kts<br>
        Alt: ${f.alt.toLocaleString()} ft<br>
        Origin: ${f.origin}
      `);
      layerGroups.flights.addLayer(marker);
      f._mapMarker = marker;
    });
  }

  function _populateShips(ships) {
    layerGroups.ships.clearLayers();
    ships.forEach(s => {
      const marker = L.marker([s.lat, s.lon], { icon: _dotIcon(COLORS.ships, 8) });
      marker.bindPopup(`<b style="color:#4488ff">${s.name}</b><br>Speed: ${Math.round(s.speed)} kts`);
      layerGroups.ships.addLayer(marker);
      s._mapMarker = marker;
    });
  }

  function _populateSatellites(sats) {
    layerGroups.satellites.clearLayers();
    sats.forEach(s => {
      if (s.currentLat === undefined) return;
      const marker = L.marker([s.currentLat, s.currentLon], { icon: _dotIcon(COLORS.satellites, 9) });
      marker.bindPopup(`<b style="color:#ffd700">${s.name}</b><br>Type: Reconnaissance<br>Source: NORAD TLE`);
      layerGroups.satellites.addLayer(marker);
      s._mapMarker = marker;
    });
  }

  function _populateJamming(zones) {
    layerGroups.jamming.clearLayers();
    zones.forEach(z => {
      const deg = z.radius * 111; // rough deg→km
      L.circle([z.lat, z.lon], {
        radius: deg * 1000,
        color: COLORS.jamming,
        fillColor: COLORS.jamming,
        fillOpacity: 0.12,
        weight: 1.5,
        opacity: 0.6,
        dashArray: '4 4',
      }).bindPopup(`<b style="color:#ff4444">GPS Jamming</b><br>${z.label}<br>Intensity: ${Math.round(z.intensity * 100)}%`)
        .addTo(layerGroups.jamming);
    });
  }

  function _populateNoFly(zones) {
    layerGroups.noflyzone.clearLayers();
    zones.forEach(z => {
      const deg = z.radius * 111;
      L.circle([z.lat, z.lon], {
        radius: deg * 1000,
        color: COLORS.noflyzone,
        fillColor: COLORS.noflyzone,
        fillOpacity: 0.1,
        weight: 2,
        opacity: 0.7,
        dashArray: '6 3',
      }).bindPopup(`<b style="color:#ff8800">No-Fly Zone</b><br>${z.label}`)
        .addTo(layerGroups.noflyzone);
    });
  }

  // ---- Sync moving markers ----
  function syncPositions(flights, ships, satellites) {
    if (!leafletReady) return;

    flights.forEach(f => {
      if (f._mapMarker) f._mapMarker.setLatLng([f.lat, f.lon]);
    });
    ships.forEach(s => {
      if (s._mapMarker) s._mapMarker.setLatLng([s.lat, s.lon]);
    });
    satellites.forEach(s => {
      if (s._mapMarker && s.currentLat !== undefined)
        s._mapMarker.setLatLng([s.currentLat, s.currentLon]);
    });
  }

  // ---- Layer toggle ----
  function toggleLayer(name) {
    if (!leafletReady || !layerGroups[name]) return;
    const group = layerGroups[name];
    if (leafletMap.hasLayer(group)) {
      leafletMap.removeLayer(group);
    } else {
      leafletMap.addLayer(group);
    }
  }

  // ---- Invalidate size when container becomes visible ----
  function invalidate() {
    if (leafletMap) leafletMap.invalidateSize();
  }

  return { init, populate, syncPositions, toggleLayer, invalidate };

})();
