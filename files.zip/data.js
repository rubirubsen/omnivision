/* =====================================================
   DATA — Shared state, simulated feeds, constants
   Later: swap simulation functions for real API calls
   (OpenSky, MarineTraffic, CelesTrak, GPSJam)
   ===================================================== */

const Data = (() => {

  // ---- Static reference data ----
  const CALLSIGNS = ['DLH','UAE','BAW','THY','SIA','QFA','AFR','KLM','LH','AA','UA','CA','EK','QR','TK'];
  const AIRPORTS  = ['FRA','DXB','LHR','IST','SIN','SYD','CDG','AMS','MUC','JFK','SFO','PEK','DOH','NRT','ICN'];

  // GPS jamming zones (static — would come from gpsjam.org API)
  const jammingZones = [
    { lat: 33.3, lon: 44.4, radius: 0.08, intensity: 0.9, label: 'Baghdad' },
    { lat: 35.0, lon: 36.2, radius: 0.07, intensity: 0.7, label: 'N.Syria' },
    { lat: 31.5, lon: 34.5, radius: 0.06, intensity: 0.8, label: 'Gaza' },
    { lat: 52.1, lon: 37.0, radius: 0.05, intensity: 0.5, label: 'Belgorod' },
  ];

  // No-fly zones (static — would come from aviation NOTAMs)
  const noFlyZones = [
    { lat: 32.0, lon: 53.0, radius: 0.12, label: 'Iran TFR' },
    { lat: 33.3, lon: 44.4, radius: 0.09, label: 'Iraq TFR' },
    { lat: 26.2, lon: 50.6, radius: 0.06, label: 'Bahrain TFR' },
  ];

  // ---- Simulated live feeds ----
  // In production: replace with OpenSky Network REST API
  // https://opensky-network.org/apidoc/rest.html
  function generateFlights(count = 120) {
    const flights = [];
    for (let i = 0; i < count; i++) {
      const lat = (Math.random() - 0.5) * 140;
      const lon = (Math.random() - 0.5) * 360;
      // Exclude Middle East conflict zone
      if (lat > 20 && lat < 40 && lon > 40 && lon < 65) continue;
      flights.push({
        id:       i,
        callsign: CALLSIGNS[i % CALLSIGNS.length] + (100 + i),
        lat,
        lon,
        speed:    400 + Math.random() * 500,
        alt:      Math.floor(28000 + Math.random() * 13000),
        heading:  Math.random() * 360,
        origin:   AIRPORTS[i % AIRPORTS.length],
        dlat:     (Math.random() - 0.5) * 0.04,
        dlon:     (Math.random() - 0.5) * 0.06,
      });
    }
    return flights;
  }

  // In production: replace with MarineTraffic / AISHub API
  function generateShips(count = 60) {
    const names = ['EVER GIVEN','MAERSK ESSEX','MSC ANNA','OOCL FRANCE','CMA CGM MARCO POLO'];
    return Array.from({ length: count }, (_, i) => ({
      id:    i,
      name:  names[i % names.length] + ` ${i + 1}`,
      lat:   (Math.random() - 0.5) * 120,
      lon:   (Math.random() - 0.5) * 360,
      speed: 10 + Math.random() * 15,
      dlat:  (Math.random() - 0.5) * 0.008,
      dlon:  (Math.random() - 0.5) * 0.012,
    }));
  }

  // In production: replace with CelesTrak TLE data + satellite.js propagation
  function generateSatellites(count = 30) {
    const names = ['KH-11','BARS-M','GAOFEN','CAPELLA','WORLDVIEW'];
    return Array.from({ length: count }, (_, i) => ({
      id:         i,
      name:       names[i % names.length] + `-${i + 1}`,
      inclination: 60 + Math.random() * 60,
      phase:      Math.random() * Math.PI * 2,
      phaseSpeed: 0.002 + Math.random() * 0.003,
    }));
  }

  // ---- Tick: advance simulation one frame ----
  function tick(flights, ships, satellites) {
    flights.forEach(f => {
      f.lat += f.dlat;
      f.lon += f.dlon;
      if (f.lat >  80) f.dlat = -Math.abs(f.dlat);
      if (f.lat < -80) f.dlat =  Math.abs(f.dlat);
      if (f.lon >  180) f.lon = -180;
      if (f.lon < -180) f.lon =  180;
    });

    ships.forEach(s => {
      s.lat += s.dlat;
      s.lon += s.dlon;
      if (s.lat >  70) s.dlat = -Math.abs(s.dlat);
      if (s.lat < -60) s.dlat =  Math.abs(s.dlat);
      if (s.lon >  180) s.lon = -180;
    });

    satellites.forEach(s => {
      s.phase += s.phaseSpeed;
      const inc  = s.inclination * Math.PI / 180;
      s.currentLat = Math.asin(Math.sin(inc) * Math.sin(s.phase)) * 180 / Math.PI;
      s.currentLon = Math.atan2(Math.cos(inc) * Math.sin(s.phase), Math.cos(s.phase)) * 180 / Math.PI;
    });
  }

  // ---- Public API ----
  return {
    jammingZones,
    noFlyZones,
    generateFlights,
    generateShips,
    generateSatellites,
    tick,
  };

})();
