/* =====================================================
   GLOBE — Three.js 3D globe renderer
   Owns: scene, camera, renderer, all 3D objects
   ===================================================== */

const Globe = (() => {

  let scene, camera, renderer;
  let globe;
  let rotX = 0.3, rotY = 0, targetRotX = 0.3, targetRotY = 0;
  let zoom = 2.8, targetZoom = 2.8;
  let isDragging = false;
  let prevMouse = { x: 0, y: 0 };

  const layers = {
    flights:    { group: null, enabled: true },
    ships:      { group: null, enabled: true },
    satellites: { group: null, enabled: true },
    jamming:    { group: null, enabled: true },
    noflyzone:  { group: null, enabled: true },
  };

  // ---- Helpers ----
  function latLonToVec3(lat, lon, radius = 1.01) {
    const phi   = (90 - lat) * Math.PI / 180;
    const theta = (lon + 180) * Math.PI / 180;
    return new THREE.Vector3(
      -radius * Math.sin(phi) * Math.cos(theta),
       radius * Math.cos(phi),
       radius * Math.sin(phi) * Math.sin(theta)
    );
  }

  function makeGlowSprite(color, size = 0.025) {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 64;
    const ctx = canvas.getContext('2d');
    const g   = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    // color is a hex string like '#00ffe0'
    const hex  = color.replace('#', '');
    const r    = parseInt(hex.slice(0, 2), 16);
    const gr   = parseInt(hex.slice(2, 4), 16);
    const b    = parseInt(hex.slice(4, 6), 16);
    g.addColorStop(0,   `rgba(${r},${gr},${b},1)`);
    g.addColorStop(0.3, `rgba(${r},${gr},${b},0.6)`);
    g.addColorStop(1,   `rgba(${r},${gr},${b},0)`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 64, 64);
    const tex = new THREE.CanvasTexture(canvas);
    const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, blending: THREE.AdditiveBlending });
    const spr = new THREE.Sprite(mat);
    spr.scale.set(size, size, 1);
    return spr;
  }

  // ---- Scene init ----
  function init(container) {
    const W = container.clientWidth, H = container.clientHeight;

    scene    = new THREE.Scene();
    scene.background = new THREE.Color(0x020408);

    camera   = new THREE.PerspectiveCamera(45, W / H, 0.1, 1000);
    camera.position.set(0, 0, zoom);

    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(W, H);
    container.appendChild(renderer.domElement);

    _buildStarfield();
    _buildGlobe();
    _buildGridLines();
    _buildLayerGroups();
    _buildLighting();
    _attachControls(renderer.domElement);

    window.addEventListener('resize', () => {
      const W = container.clientWidth, H = container.clientHeight;
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      renderer.setSize(W, H);
    });
  }

  function _buildStarfield() {
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(8000 * 3);
    for (let i = 0; i < pos.length; i++) pos[i] = (Math.random() - 0.5) * 400;
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    scene.add(new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xaaccff, size: 0.3, sizeAttenuation: true })));
  }

  function _buildGlobe() {
    const texLoader = new THREE.TextureLoader();
    const earthTex  = texLoader.load('https://threejs.org/examples/textures/land_ocean_ice_cloud_2048.jpg');

    globe = new THREE.Mesh(
      new THREE.SphereGeometry(1, 64, 64),
      new THREE.MeshPhongMaterial({ map: earthTex, specular: new THREE.Color(0x112233), shininess: 15 })
    );
    scene.add(globe);

    // Atmosphere tint
    scene.add(new THREE.Mesh(
      new THREE.SphereGeometry(1.02, 64, 64),
      new THREE.MeshPhongMaterial({ color: 0x0033ff, transparent: true, opacity: 0.07, side: THREE.FrontSide })
    ));

    // Fresnel glow
    scene.add(new THREE.Mesh(
      new THREE.SphereGeometry(1.05, 64, 64),
      new THREE.ShaderMaterial({
        vertexShader: `
          varying vec3 vNormal;
          void main() {
            vNormal = normalize(normalMatrix * normal);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }`,
        fragmentShader: `
          varying vec3 vNormal;
          void main() {
            float intensity = pow(0.6 - dot(vNormal, vec3(0,0,1)), 3.0);
            gl_FragColor = vec4(0.0, 0.8, 1.0, intensity * 0.5);
          }`,
        blending: THREE.AdditiveBlending,
        side: THREE.BackSide,
        transparent: true,
      })
    ));
  }

  function _buildGridLines() {
    const mat = new THREE.LineBasicMaterial({ color: 0x00ffe0, transparent: true, opacity: 0.055 });
    for (let lat = -80; lat <= 80; lat += 20) {
      const pts = [];
      for (let lon = 0; lon <= 361; lon += 2) pts.push(latLonToVec3(lat, lon, 1.001));
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat));
    }
    for (let lon = 0; lon < 360; lon += 20) {
      const pts = [];
      for (let lat = -90; lat <= 90; lat += 2) pts.push(latLonToVec3(lat, lon, 1.001));
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat));
    }
  }

  function _buildLayerGroups() {
    Object.values(layers).forEach(l => {
      l.group = new THREE.Group();
      scene.add(l.group);
    });
  }

  function _buildLighting() {
    scene.add(new THREE.AmbientLight(0x222244, 1));
    const sun = new THREE.DirectionalLight(0xffffff, 1.5);
    sun.position.set(5, 3, 5);
    scene.add(sun);
  }

  // ---- Controls ----
  function _attachControls(el) {
    el.addEventListener('mousedown', e => {
      isDragging = true;
      prevMouse  = { x: e.clientX, y: e.clientY };
      document.body.classList.add('dragging');
    });
    window.addEventListener('mouseup', () => {
      isDragging = false;
      document.body.classList.remove('dragging');
    });
    el.addEventListener('mousemove', e => {
      if (!isDragging) return;
      targetRotY += (e.clientX - prevMouse.x) * 0.005;
      targetRotX += (e.clientY - prevMouse.y) * 0.005;
      targetRotX  = Math.max(-1.4, Math.min(1.4, targetRotX));
      prevMouse   = { x: e.clientX, y: e.clientY };
    });
    el.addEventListener('wheel', e => {
      targetZoom += e.deltaY * 0.002;
      targetZoom  = Math.max(1.4, Math.min(5, targetZoom));
    }, { passive: true });

    // Touch
    let lastTouch = null;
    el.addEventListener('touchstart', e => { isDragging = true; lastTouch = e.touches[0]; });
    el.addEventListener('touchend',   () => { isDragging = false; });
    el.addEventListener('touchmove',  e => {
      if (!isDragging || !lastTouch) return;
      targetRotY += (e.touches[0].clientX - lastTouch.clientX) * 0.005;
      targetRotX += (e.touches[0].clientY - lastTouch.clientY) * 0.005;
      lastTouch   = e.touches[0];
      e.preventDefault();
    }, { passive: false });
  }

  // ---- Populate layers from data ----
  function populate(flights, ships, satellites, jammingZones, noFlyZones) {
    _populateFlights(flights);
    _populateShips(ships);
    _populateSatellites(satellites);
    _populateJamming(jammingZones);
    _populateNoFly(noFlyZones);
  }

  function _populateFlights(flights) {
    layers.flights.group.clear();
    flights.forEach(f => {
      const s = makeGlowSprite('#00ffe0', 0.022);
      s.position.copy(latLonToVec3(f.lat, f.lon, 1.015));
      s.userData = { type: 'flight', data: f };
      layers.flights.group.add(s);
      f._sprite = s;
    });
  }

  function _populateShips(ships) {
    layers.ships.group.clear();
    ships.forEach(s => {
      const sp = makeGlowSprite('#4488ff', 0.02);
      sp.position.copy(latLonToVec3(s.lat, s.lon, 1.01));
      sp.userData = { type: 'ship', data: s };
      layers.ships.group.add(sp);
      s._sprite = sp;
    });
  }

  function _populateSatellites(sats) {
    layers.satellites.group.clear();
    sats.forEach(s => {
      const sp = makeGlowSprite('#ffd700', 0.024);
      sp.userData = { type: 'satellite', data: s };
      layers.satellites.group.add(sp);
      s._sprite = sp;
    });
  }

  function _populateJamming(zones) {
    layers.jamming.group.clear();
    zones.forEach(z => {
      const center = latLonToVec3(z.lat, z.lon, 1.002);
      const look   = new THREE.Vector3(0, 0, 0);

      const fill = new THREE.Mesh(
        new THREE.CircleGeometry(z.radius, 32),
        new THREE.MeshBasicMaterial({ color: 0xff2222, transparent: true, opacity: 0.15, side: THREE.DoubleSide })
      );
      fill.position.copy(center); fill.lookAt(look);
      layers.jamming.group.add(fill);

      const ring = new THREE.Mesh(
        new THREE.RingGeometry(z.radius * 0.88, z.radius, 32),
        new THREE.MeshBasicMaterial({ color: 0xff4444, transparent: true, opacity: 0.55, side: THREE.DoubleSide })
      );
      ring.position.copy(center); ring.lookAt(look);
      layers.jamming.group.add(ring);
    });
  }

  function _populateNoFly(zones) {
    layers.noflyzone.group.clear();
    zones.forEach(z => {
      const center = latLonToVec3(z.lat, z.lon, 1.003);
      const look   = new THREE.Vector3(0, 0, 0);

      const fill = new THREE.Mesh(
        new THREE.CircleGeometry(z.radius, 48),
        new THREE.MeshBasicMaterial({ color: 0xff8800, transparent: true, opacity: 0.12, side: THREE.DoubleSide })
      );
      fill.position.copy(center); fill.lookAt(look);
      layers.noflyzone.group.add(fill);

      const ring = new THREE.Mesh(
        new THREE.RingGeometry(z.radius * 0.92, z.radius, 48),
        new THREE.MeshBasicMaterial({ color: 0xff8800, transparent: true, opacity: 0.6, side: THREE.DoubleSide })
      );
      ring.position.copy(center); ring.lookAt(look);
      layers.noflyzone.group.add(ring);
    });
  }

  // ---- Per-frame sync after data.tick() ----
  function syncPositions(flights, ships, satellites) {
    if (layers.flights.enabled) {
      flights.forEach(f => {
        if (f._sprite) f._sprite.position.copy(latLonToVec3(f.lat, f.lon, 1.015));
      });
    }
    if (layers.ships.enabled) {
      ships.forEach(s => {
        if (s._sprite) s._sprite.position.copy(latLonToVec3(s.lat, s.lon, 1.01));
      });
    }
    if (layers.satellites.enabled) {
      satellites.forEach(s => {
        if (s._sprite && s.currentLat !== undefined)
          s._sprite.position.copy(latLonToVec3(s.currentLat, s.currentLon, 1.06));
      });
    }
  }

  // ---- Render tick ----
  function render(t) {
    rotX += (targetRotX - rotX) * 0.08;
    rotY += (targetRotY - rotY) * 0.08;
    zoom += (targetZoom - zoom)  * 0.06;

    globe.rotation.x = rotX;
    globe.rotation.y = rotY;
    Object.values(layers).forEach(l => {
      l.group.rotation.x = rotX;
      l.group.rotation.y = rotY;
    });

    camera.position.z = zoom;

    // Auto-rotate when idle
    if (!isDragging) targetRotY += 0.0005;

    // Pulse jamming fill opacity
    if (layers.jamming.enabled) {
      layers.jamming.group.children.forEach((m, i) => {
        if (m.material?.opacity !== undefined && i % 2 === 0) {
          m.material.opacity = 0.06 + 0.1 * Math.sin(t * 2 + i);
        }
      });
    }

    renderer.render(scene, camera);
  }

  // ---- Layer toggle ----
  function toggleLayer(name) {
    const l = layers[name];
    if (!l) return;
    l.enabled     = !l.enabled;
    l.group.visible = l.enabled;
  }

  // ---- Raycaster for hover ----
  function getHitAtMouse(mouseNDC) {
    const raycaster = new THREE.Raycaster();
    raycaster.params.Sprite = { threshold: 0.03 };
    raycaster.setFromCamera(mouseNDC, camera);
    const allSprites = [
      ...layers.flights.group.children,
      ...layers.ships.group.children,
      ...layers.satellites.group.children,
    ].filter(s => s.parent?.visible);
    const hits = raycaster.intersectObjects(allSprites);
    return hits.length > 0 ? hits[0].object.userData : null;
  }

  function getCanvas() { return renderer?.domElement; }

  return { init, populate, syncPositions, render, toggleLayer, getHitAtMouse, getCanvas };

})();
