/* =====================================================
   APP — Main orchestrator
   Wires: Data ↔ Globe ↔ Map2D ↔ HUD
   All modules are independent; this is the only place
   they know about each other.
   ===================================================== */

const App = (() => {

  // ---- State ----
  let flights, ships, satellites;
  let currentView = 'globe';
  let t = 0;

  const layerState = {
    flights:    true,
    ships:      true,
    satellites: true,
    jamming:    true,
    noflyzone:  true,
  };

  // ---- Bootstrap ----
  function init() {
    // Generate initial data
    flights    = Data.generateFlights(120);
    ships      = Data.generateShips(60);
    satellites = Data.generateSatellites(30);

    // Run one data tick so satellites have currentLat/Lon
    Data.tick(flights, ships, satellites);

    // Init 3D globe
    Globe.init(document.getElementById('canvas-container'));
    Globe.populate(flights, ships, satellites, Data.jammingZones, Data.noFlyZones);

    // Init HUD
    HUD.startClock();
    HUD.updateStats({ flights, ships, jammingZones: Data.jammingZones, satellites });

    // Wire globe hover → tooltip
    _attachGlobeHover();

    // Start loop
    _loop();
  }

  // ---- Main loop ----
  function _loop() {
    requestAnimationFrame(_loop);
    t += 0.016;

    Data.tick(flights, ships, satellites);
    Globe.syncPositions(flights, ships, satellites);

    if (currentView === 'map') {
      Map2D.syncPositions(flights, ships, satellites);
    }

    Globe.render(t);
  }

  // ---- View switching ----
  async function setView(view) {
    if (view === currentView) return;
    currentView = view;
    HUD.setActiveView(view);

    const globeContainer = document.getElementById('canvas-container');
    const mapContainer   = document.getElementById('map-container');

    if (view === 'map') {
      globeContainer.style.display = 'none';
      mapContainer.style.display   = 'block';
      // Lazy init map on first switch
      await Map2D.init(mapContainer);
      Map2D.populate(flights, ships, satellites, Data.jammingZones, Data.noFlyZones);
      Map2D.invalidate();
      // Sync toggle states
      Object.entries(layerState).forEach(([name, enabled]) => {
        if (!enabled) Map2D.toggleLayer(name);
      });
    } else {
      mapContainer.style.display   = 'none';
      globeContainer.style.display = 'block';
    }
  }

  // ---- Layer toggle ----
  function toggleLayer(name) {
    layerState[name] = !layerState[name];
    HUD.setToggleState(name, layerState[name]);
    Globe.toggleLayer(name);
    if (currentView === 'map') Map2D.toggleLayer(name);
  }

  // ---- Globe hover / tooltip ----
  function _attachGlobeHover() {
    const canvas = Globe.getCanvas();
    if (!canvas) return;
    const mouse = new THREE.Vector2();

    canvas.addEventListener('mousemove', e => {
      mouse.x =  (e.clientX / window.innerWidth)  * 2 - 1;
      mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
      const hit = Globe.getHitAtMouse(mouse);
      HUD.showTooltip(e.clientX, e.clientY, hit);
    });

    canvas.addEventListener('mouseleave', () => HUD.hideTooltip());
  }

  // ---- Public ----
  return { init, setView, toggleLayer };

})();

// ---- Kick off ----
document.addEventListener('DOMContentLoaded', () => App.init());
