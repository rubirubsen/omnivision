/* =====================================================
   HUD — Clock, stats panel, tooltip, layer toggles
   Pure DOM manipulation, no rendering logic
   ===================================================== */

const HUD = (() => {

  // ---- Clock ----
  function startClock() {
    const el = document.getElementById('clock');
    function tick() {
      el.textContent = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    }
    tick();
    setInterval(tick, 1000);
  }

  // ---- Stats ----
  function updateStats({ flights, ships, jammingZones, satellites }) {
    document.getElementById('ac-count').textContent    = flights.length.toLocaleString();
    document.getElementById('ship-count').textContent  = ships.length.toLocaleString();
    document.getElementById('jam-count').textContent   = jammingZones.length;
    document.getElementById('sat-count').textContent   = satellites.length;
  }

  // ---- Tooltip ----
  const tooltip = document.getElementById('tooltip');

  function showTooltip(x, y, userData) {
    if (!userData) { hideTooltip(); return; }

    const { type, data } = userData;

    tooltip.style.display = 'block';
    tooltip.style.left    = (x + 16) + 'px';
    tooltip.style.top     = (y - 10) + 'px';

    if (type === 'flight') {
      _setTooltip(data.callsign, 'Commercial Flight',
        Math.round(data.speed) + ' kts',
        data.alt.toLocaleString() + ' ft',
        data.origin);
    } else if (type === 'ship') {
      _setTooltip(data.name, 'Cargo Vessel',
        Math.round(data.speed) + ' kts',
        'Surface',
        'AIS Beacon');
    } else if (type === 'satellite') {
      _setTooltip(data.name, 'Reconnaissance Sat',
        '~17,500 mph',
        '~400 km LEO',
        'NORAD TLE');
    }
  }

  function hideTooltip() {
    tooltip.style.display = 'none';
  }

  function _setTooltip(name, type, speed, alt, origin) {
    document.getElementById('tip-name').textContent   = name;
    document.getElementById('tip-type').textContent   = type;
    document.getElementById('tip-speed').textContent  = speed;
    document.getElementById('tip-alt').textContent    = alt;
    document.getElementById('tip-origin').textContent = origin;
  }

  // ---- Layer toggle button state ----
  function setToggleState(name, enabled) {
    const el = document.getElementById('toggle-' + name);
    if (el) el.className = 'toggle ' + (enabled ? 'on' : 'off');
  }

  // ---- View mode buttons ----
  function setActiveView(view) {
    document.getElementById('btn-globe').classList.toggle('active', view === 'globe');
    document.getElementById('btn-map').classList.toggle('active', view === 'map');
  }

  return { startClock, updateStats, showTooltip, hideTooltip, setToggleState, setActiveView };

})();
